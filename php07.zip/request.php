<!DOCTYPE html>
<html lang="en">
<head>
    <title>Example of PHP $_REQUEST variable</title>
</head>
<body>
<?php
if(isset($_REQUEST["name"])) {
    echo "<p>Hi, ". $_REQUEST["name"] ."</p>";
}
?>
<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
    <label for="inputName">Name : </label>
    <input type="text" name="name" id="inputName">
    <input type="submit" value="Sumbit">
</form>
</body>
</html>